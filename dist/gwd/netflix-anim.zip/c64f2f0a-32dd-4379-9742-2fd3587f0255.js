
/* an-ER-fade-in:c64f2f0a-32dd-4379-9742-2fd3587f0255.js, VERSION: 5.0.0, Published: 2019/04/03 16:54:26 $*/
// GENERIC SOURCE TRACKER: an-ER-fade-in
if (typeof module === 'undefined') {
  module = {};
}
// prettier-ignore
module.exports = {
  "id": "c64f2f0a-32dd-4379-9742-2fd3587f0255",
  "name": "an-ER-fade-in",
  "description": "CTA button",
  "type": "animations",
  "context": "Default",
  "state": "published",
  "updated": 1544728889095,
  "full_name": "NetflixDev/an-ER-fade-in",
  "html_url": "https://github.com/NetflixDev/an-ER-fade-in",
  "username": "GitHub",
  "version": "5.0.0",
  "minimum": "3.0.0"
}
